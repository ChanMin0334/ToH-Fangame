// 해시 기반 라우터 (모바일 친화)
// 각 탭 모듈은 export function render(root) 형태로 View를 그린다.
export function initRouter(routes){
  function render(){
    const path = location.hash.replace('#','') || '/home';
    const View = routes[path] || routes['/home'];
    const root = document.querySelector('#view');
    // 하단바 active 처리
    document.querySelectorAll('.bottombar a').forEach(a=>{
      a.classList.toggle('active', a.getAttribute('href') === '#'+path);
    });
    root.innerHTML = ''; // 초기화
    View(root);
  }
  window.addEventListener('hashchange', render);
  render();
}

export function navigate(path){
  location.hash = path;
}
