// 앱 부트스트랩: 라우터 초기화, 탭 등록
import { initRouter, navigate } from './router.js';
import { HomeTab } from './tabs/home.js';
import { AdventureTab } from './tabs/adventure.js';
import { RankingsTab } from './tabs/rankings.js';
import { FriendsTab } from './tabs/friends.js';
import { MeTab } from './tabs/me.js';
import { loadWorlds, getCurrentWorld, setCurrentWorld } from './api/worlds.js';

const routes = {
  '/home': HomeTab,
  '/adventure': AdventureTab,
  '/rankings': RankingsTab,
  '/friends': FriendsTab,
  '/me': MeTab,
};

window.appState = {
  creationLock: false,     // 캐릭터 생성 중복 방지
  currentWorldId: null,
};

// 세계관 로드 후 기본값 설정
(async () => {
  await loadWorlds();
  if(!getCurrentWorld()){
    // 첫 진입 시 첫 세계관으로 기본 선택
    const first = window.worlds?.[0];
    if(first) setCurrentWorld(first.id);
  }
  document.querySelector('#worldName').textContent = getCurrentWorld()?.name || '-';
  initRouter(routes);
  if(!location.hash) navigate('/home');
})();
