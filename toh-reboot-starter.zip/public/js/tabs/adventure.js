// 모험 탭: 세계관 던전/유적 탐험, 레이드 진입, 아이템 파밍
import { getWorlds, setCurrentWorld, getCurrentWorld } from '../api/worlds.js';

export function AdventureTab(root){
  const worlds = getWorlds() || [];
  const sel = document.createElement('div');
  sel.className = 'card';
  sel.innerHTML = `<h3>세계관 선택</h3>
  <select id="worldSel">${worlds.map(w=>`<option value="${w.id}">${w.name}</option>`).join('')}</select>
  <p class="muted">세계관을 바꾸면 배경/던전/레이드가 달라집니다.</p>`;
  root.appendChild(sel);
  const worldSel = sel.querySelector('#worldSel');
  worldSel.value = getCurrentWorld()?.id || (worlds[0]?.id || '');
  worldSel.onchange = ()=>{
    setCurrentWorld(worldSel.value);
    document.querySelector('#worldName').textContent = getCurrentWorld()?.name || '-';
    alert('세계관이 변경되었어요.');
  };

  const places = document.createElement('div');
  places.className = 'card';
  places.innerHTML = `<h3>유적지/명소</h3>
  <div id="placeList" class="grid"></div>`;
  root.appendChild(places);

  const list = places.querySelector('#placeList');
  const w = getCurrentWorld();
  (w?.detail?.places || []).forEach(p=>{
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `<strong>${p.name}</strong><p class="muted">${p.type||''} · ${(p.tags||[]).join(', ')}</p>
    <button class="btn">탐험(조우 생성)</button>`;
    el.querySelector('button').onclick = ()=> alert('여기서 스케치(저가) 호출 → 정제(고가) → 결과');
    list.appendChild(el);
  });
}
