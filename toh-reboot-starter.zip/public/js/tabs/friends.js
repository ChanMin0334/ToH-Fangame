// 친구 탭: 친구 추가/목록/초대
export function FriendsTab(root){
  const box = document.createElement('div');
  box.className = 'card';
  box.innerHTML = `<h3>친구</h3>
  <input placeholder="친구 검색(닉네임/ID)"/>
  <button class="btn">검색</button>
  <div class="muted">친구 추가 후 일반 조우를 만들 수 있어요.</div>`;
  root.appendChild(box);
}
