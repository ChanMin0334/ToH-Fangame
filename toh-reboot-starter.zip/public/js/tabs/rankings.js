// 랭킹 탭: 인기(좋아요 주간/전체), Elo, 세계관 승률
export function RankingsTab(root){
  const box = document.createElement('div');
  box.className = 'card';
  box.innerHTML = `<h3>랭킹</h3>
  <ul>
    <li>인기(좋아요) — 주간 랭킹 / 전체 누적</li>
    <li>Elo 점수 랭킹</li>
    <li>세계관 승률 랭킹 (세계관 정보 확인 가능)</li>
  </ul>
  <p class="muted">※ 주간 초기화 후 얻은 좋아요만 주간 랭킹에 반영되며, 기본적으로는 전체 누적 좋아요도 유지됩니다. 주간이 지나면 다시 같은 캐릭터에 좋아요 가능.</p>`;
  root.appendChild(box);
}
