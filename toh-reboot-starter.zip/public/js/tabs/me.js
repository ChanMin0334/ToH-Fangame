// 내정보 탭: 로그인 상태, BYOK, 환경설정(리롤 한도 등 표시만)
export function MeTab(root){
  const box = document.createElement('div');
  box.className = 'card';
  box.innerHTML = `<h3>내 정보</h3>
  <p class="muted">로그인 상태 / BYOK / 일일 에피소드 생성 현황 등을 표시합니다.</p>
  <button class="btn">로그인 / 로그아웃 (추후 연결)</button>`;
  root.appendChild(box);
}
