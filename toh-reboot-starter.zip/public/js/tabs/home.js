// 홈 탭: 캐릭터 카드 그리드 + 생성 카드
import { navigate } from '../router.js';
import { getCurrentWorld } from '../api/worlds.js';

export function HomeTab(root){
  const wrap = document.createElement('div');
  wrap.className = 'grid cards';

  // TODO: Firestore에서 내 캐릭터 목록 가져오기. 지금은 자리표시자.
  const myChars = []; // [{id,name,summary,likes,elo,wins,losses}, ...]

  const addCard = document.createElement('div');
  addCard.className = 'card';
  addCard.innerHTML = `<strong>+ 새 캐릭터 만들기</strong>
  <p class="muted">세계관: ${getCurrentWorld()?.name || '-'}</p>
  <button class="btn" id="goCreate">캐릭터 생성</button>`;
  addCard.querySelector('#goCreate').onclick = ()=> navigate('/home#create'); // 간단 라우팅
  wrap.appendChild(addCard);

  myChars.forEach(c=>{
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `<strong>${c.name}</strong>
      <p class="muted">${c.summary || ''}</p>
      <button class="btn">캐릭터 정보</button>`;
    el.querySelector('button').onclick = ()=> alert('캐릭터 상세 화면은 추후 탭으로 연결');
    wrap.appendChild(el);
  });

  root.appendChild(wrap);

  // 생성 폼(간단 자리표시자)
  if(location.hash.endsWith('#create')){
    const form = document.createElement('div');
    form.className = 'card';
    form.innerHTML = `<h3>캐릭터 생성</h3>
      <label>세계관 (현재 선택): ${getCurrentWorld()?.name || '-'}</label>
      <input id="name" placeholder="이름(20자 이하)" maxlength="20"/>
      <textarea id="info" placeholder="설정 및 정보(500자 이하)" maxlength="500"></textarea>
      <button class="btn" id="createBtn">생성 시작</button>
      <p class="muted">※ 생성 중에는 다른 생성 요청이 잠시 비활성화됩니다.</p>`;
    form.querySelector('#createBtn').onclick = ()=> alert('여기서 저가→고가 파이프라인 호출 / creationLock 사용');
    root.appendChild(form);
  }
}
