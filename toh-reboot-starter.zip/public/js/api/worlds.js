// 세계관 로더 & 현재 세계관 상태
let worldsCache = null;
const LS_KEY = 'toh_current_world';

export async function loadWorlds(){
  if(worldsCache) return worldsCache;
  const res = await fetch('./assets/worlds.json');
  const data = await res.json();
  window.worlds = data.worlds || [];
  return worldsCache = window.worlds;
}

export function getWorlds(){ return window.worlds || []; }

export function setCurrentWorld(id){
  const w = (window.worlds || []).find(x=>x.id===id);
  if(!w) return;
  localStorage.setItem(LS_KEY, id);
  window.currentWorld = w;
}

export function getCurrentWorld(){
  if(window.currentWorld) return window.currentWorld;
  const id = localStorage.getItem(LS_KEY);
  const w = (window.worlds || []).find(x=>x.id===id);
  if(w){ window.currentWorld = w; return w; }
  return null;
}
