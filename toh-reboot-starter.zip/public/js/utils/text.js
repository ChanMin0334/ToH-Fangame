// 글자/문장 제한 유틸 (프론트 검증용)
export function charCount(s=''){ return [...(s||'')].length; }

export function sentenceCount(s=''){
  // 마침표/물음표/느낌표/줄바꿈 기준의 매우 단순 카운트
  return (s||'').split(/(?<=[\.\?\!])|\n+/).filter(x=>x && x.trim()).length;
}
