# 데이터 스키마 요약

## 1) 세계관 worlds.json
- id, name, intro(요약), detail.lore, detail.places[] {id,name,type,tags[]}

## 2) 캐릭터
- name(≤20), inputInfo(≤500), abilities 4개 (name≤20, desc≤100, ≤4문장), narrative(≤1000, ≤20문장), summary(≤200, ≤8문장)

## 3) 조우(Encounter)
- where/why/what/result 3축
- 스케치(저가) 3안 → 내부 랜덤 1안 채택
- 정제(고가) 1회

## 4) 관계/에피소드
- 관계: 캐릭터쌍 슬롯 1개, 공격자만 생성, 양측 삭제 자유, 배틀 종료 후 10분 내
- 에피소드: 하루 1개(본문 ≤500자, ≤25문장 / 요약 리롤 무한)
